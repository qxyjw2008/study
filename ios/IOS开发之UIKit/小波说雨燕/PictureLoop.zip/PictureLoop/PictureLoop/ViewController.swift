//
//  ViewController.swift
//  PictureLoop
//
//  Created by Benjamin on 12/3/15.
//  Copyright © 2015 Benjamin. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIScrollViewDelegate {

    
    @IBOutlet weak var pageControl1: UIPageControl!
    @IBOutlet weak var scrollView1: UIScrollView!
    let images = ["s1", "s2", "s3"]
    var timer = NSTimer()
    //图片的宽
    var imageWidth:CGFloat {
        return scrollView1.frame.size.width
    }
    //图片的高
    var imageHeight:CGFloat {
        return scrollView1.frame.size.height
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let scrollWidth = self.scrollView1.frame.size.width
        let mainWidth = UIScreen.mainScreen().bounds.size.width
        self.scrollView1.setNeedsLayout()
        print("屏幕宽度: \(mainWidth), scrollView宽度: \(scrollWidth)")
        /*let mainWidth = UIScreen.mainScreen().bounds.size.width
        let imageY: CGFloat = 0
        let imageWidth = self.scrollView1.frame.size.width
        let imageHeight = self.scrollView1.frame.size.height
        for i in 0..<images.count {
            let imageX = imageWidth * CGFloat(i)
            let imageView = UIImageView(image: UIImage(named: images[i]))
            print("屏幕宽度: \(mainWidth)")
            print("加入image \(images[i]), imagex: \(imageX)")
            imageView.frame = CGRectMake(imageX, imageY, imageWidth, imageHeight)
            self.scrollView1.addSubview(imageView)
        }
        let contentWidth = CGFloat(images.count) * imageWidth
        //设置scrollView的滚动范围
        self.scrollView1.contentSize = CGSizeMake(contentWidth, 0)
        
        //要分页
        self.scrollView1.pagingEnabled = true
        
        self.scrollView1.delegate = self
        
        //取消水平垂直滚动条
        scrollView1.showsHorizontalScrollIndicator = false
        scrollView1.showsVerticalScrollIndicator = false
        
        self.pageControl1.numberOfPages = images.count
        self.pageControl1.currentPage = 0
        addTimer()*/
    }
    
    //轮回下张图片
    func nextImage() {
        var currentPage = self.pageControl1.currentPage
        if currentPage == images.count-1 {
            currentPage = 0
        } else {
            currentPage++
        }
        print("下一张图片的currentPage: \(currentPage)")
        let offsetX = imageWidth * CGFloat(currentPage)
        print("图片的宽度 \(imageWidth), 偏移量: \(offsetX)")
        self.scrollView1.contentOffset = CGPointMake(offsetX, 0)
    }
    
    func scrollViewDidScroll(scrollView: UIScrollView) {
        print("滚动中")
        let offsetX = self.scrollView1.contentOffset.x
        self.pageControl1.currentPage = Int(offsetX / imageWidth)
    }
    //开始拖拽
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        removeTimer()
    }
    
    //停止拖拽
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        addTimer()
    }
    
    func addTimer() {
        self.timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "nextImage", userInfo: nil, repeats: true)
        //添加到运行循环
        NSRunLoop.currentRunLoop().addTimer(self.timer, forMode: NSRunLoopCommonModes)
    }
    
    //关闭定时器
    func removeTimer() {
        self.timer.invalidate()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

