//
//  ViewController.h
//  微信支付Demo
//
//  Created by 周琦 on 15/10/29.
//  Copyright © 2015年 蓝鸥科技. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

