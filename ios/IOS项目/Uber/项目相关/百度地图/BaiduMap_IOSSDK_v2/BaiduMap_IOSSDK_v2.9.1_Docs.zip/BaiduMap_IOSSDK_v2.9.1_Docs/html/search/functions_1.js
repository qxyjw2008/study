var searchData=
[
  ['addannotation_3a',['addAnnotation:',['../category_b_m_k_map_view_07_annotation_a_p_i_08.html#a2af9ed45c3a7fd530dd414dc573327b3',1,'BMKMapView(AnnotationAPI)::addAnnotation:()'],['../interface_b_m_k_map_view.html#a2af9ed45c3a7fd530dd414dc573327b3',1,'BMKMapView::addAnnotation:()']]],
  ['addannotations_3a',['addAnnotations:',['../category_b_m_k_map_view_07_annotation_a_p_i_08.html#affd032313c55ae27814430b760e4aea0',1,'BMKMapView(AnnotationAPI)::addAnnotations:()'],['../interface_b_m_k_map_view.html#affd032313c55ae27814430b760e4aea0',1,'BMKMapView::addAnnotations:()']]],
  ['addfavpoi_3a',['addFavPoi:',['../interface_b_m_k_fav_poi_manager.html#ad34be09541e56b63341787f240c28dca',1,'BMKFavPoiManager']]],
  ['addheatmap_3a',['addHeatMap:',['../category_b_m_k_map_view_07_heat_map_a_p_i_08.html#a5945dec15b2d38ecf4b8efd4ce6b49e2',1,'BMKMapView(HeatMapAPI)::addHeatMap:()'],['../interface_b_m_k_map_view.html#a5945dec15b2d38ecf4b8efd4ce6b49e2',1,'BMKMapView::addHeatMap:()']]],
  ['addoverlay_3a',['addOverlay:',['../category_b_m_k_map_view_07_overlays_a_p_i_08.html#af85ad6091568df29d9e7c3dea82a1a2b',1,'BMKMapView(OverlaysAPI)::addOverlay:()'],['../interface_b_m_k_map_view.html#af85ad6091568df29d9e7c3dea82a1a2b',1,'BMKMapView::addOverlay:()']]],
  ['addoverlays_3a',['addOverlays:',['../category_b_m_k_map_view_07_overlays_a_p_i_08.html#ab7d29d948515cc6d947d6aa63f904168',1,'BMKMapView(OverlaysAPI)::addOverlays:()'],['../interface_b_m_k_map_view.html#ab7d29d948515cc6d947d6aa63f904168',1,'BMKMapView::addOverlays:()']]],
  ['addradarmanagerdelegate_3a',['addRadarManagerDelegate:',['../interface_b_m_k_radar_manager.html#a82396fd5134572b965e2afb39c592a48',1,'BMKRadarManager']]],
  ['applyfillpropertiestocontext_3aatzoomscale_3a',['applyFillPropertiesToContext:atZoomScale:',['../interface_b_m_k_overlay_path_view.html#af549bea37a94164a088826f9a962e08c',1,'BMKOverlayPathView']]],
  ['applystrokepropertiestocontext_3aatzoomscale_3a',['applyStrokePropertiesToContext:atZoomScale:',['../interface_b_m_k_overlay_path_view.html#a2acbf6bd9401c2904148b7b6cf85c6e9',1,'BMKOverlayPathView']]],
  ['arclinewithcoordinates_3a',['arclineWithCoordinates:',['../interface_b_m_k_arcline.html#a34a5daa9fc480861aa52e2ef5b0ccb3a',1,'BMKArcline']]],
  ['arclinewithpoints_3a',['arclineWithPoints:',['../interface_b_m_k_arcline.html#ad439d6682d48b51c0b04e84772a38a79',1,'BMKArcline']]]
];
