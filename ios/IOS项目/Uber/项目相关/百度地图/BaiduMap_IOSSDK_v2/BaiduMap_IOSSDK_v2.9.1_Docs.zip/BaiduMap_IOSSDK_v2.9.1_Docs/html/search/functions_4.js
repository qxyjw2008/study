var searchData=
[
  ['deletefavpoi_3a',['deleteFavPoi:',['../interface_b_m_k_fav_poi_manager.html#ac3ab3cb3912e4d1e08a971d4d1a23d7b',1,'BMKFavPoiManager']]],
  ['dequeuereusableannotationviewwithidentifier_3a',['dequeueReusableAnnotationViewWithIdentifier:',['../category_b_m_k_map_view_07_annotation_a_p_i_08.html#a4d4aa7a171876f3f66add8f86cca1e8c',1,'BMKMapView(AnnotationAPI)::dequeueReusableAnnotationViewWithIdentifier:()'],['../interface_b_m_k_map_view.html#a4d4aa7a171876f3f66add8f86cca1e8c',1,'BMKMapView::dequeueReusableAnnotationViewWithIdentifier:()']]],
  ['deselectannotation_3aanimated_3a',['deselectAnnotation:animated:',['../category_b_m_k_map_view_07_annotation_a_p_i_08.html#a3d6bbc91bc3b66463ee97b3c909e4999',1,'BMKMapView(AnnotationAPI)::deselectAnnotation:animated:()'],['../interface_b_m_k_map_view.html#a3d6bbc91bc3b66463ee97b3c909e4999',1,'BMKMapView::deselectAnnotation:animated:()']]],
  ['detailsearchwithsearchinfo_3a',['detailSearchWithSearchInfo:',['../interface_b_m_k_cloud_search.html#aaa7dcb1e49edd705290a3e79d8d22e92',1,'BMKCloudSearch']]],
  ['didfailtolocateuserwitherror_3a',['didFailToLocateUserWithError:',['../protocol_b_m_k_location_service_delegate-p.html#a8653218e26f920bf67513c2c4fffb5be',1,'BMKLocationServiceDelegate-p']]],
  ['didforeground',['didForeGround',['../interface_b_m_k_map_view.html#ae9e5519e547a14d2fc5479c28f724560',1,'BMKMapView']]],
  ['didstoplocatinguser',['didStopLocatingUser',['../protocol_b_m_k_location_service_delegate-p.html#a03d0086502462319e2a007b837dc7e26',1,'BMKLocationServiceDelegate-p']]],
  ['didupdatebmkuserlocation_3a',['didUpdateBMKUserLocation:',['../protocol_b_m_k_location_service_delegate-p.html#a3e9ba0b7fca0295aa46a2ad5a179645d',1,'BMKLocationServiceDelegate-p']]],
  ['didupdateuserheading_3a',['didUpdateUserHeading:',['../protocol_b_m_k_location_service_delegate-p.html#a93b210b6948016039b9286cdb350cf13',1,'BMKLocationServiceDelegate-p']]],
  ['drawmaprect_3azoomscale_3aincontext_3a',['drawMapRect:zoomScale:inContext:',['../interface_b_m_k_overlay_view.html#aad771b4c325461d99b142e79287188dc',1,'BMKOverlayView']]],
  ['drivingsearch_3a',['drivingSearch:',['../interface_b_m_k_route_search.html#a64bca1276cae03de35f61a0f733d6135',1,'BMKRouteSearch']]]
];
